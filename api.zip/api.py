from fastapi import FastAPI, HTTPException
import requests

app = FastAPI()

@app.get("/extract")
def extract_asos(product_id: str): # <--- Added parameter here
    # The URL now uses the product_id variable
    url = f"https://www.asos.com/api/product/catalogue/v4/summaries?productIds={product_id}&store=COM"
    
    try:
        response = requests.get(url)
        
        if response.status_code == 200:
            data_list = response.json()
            
            # Check if the list is empty (product ID not found)
            if not data_list:
                raise HTTPException(status_code=404, detail="Product not found")
                
            raw_data = data_list[0]
            
            return {
                "title": raw_data.get("name"),
                "brand": raw_data.get("brandName"),
                "images": [f"https://{img.get("url")}" for img in raw_data.get("images", []) if img.get("isPrimary")],
                "url": raw_data.get('pdpUrl')
            }
        else:
            raise HTTPException(status_code=response.status_code, detail="ASOS API rejected the request")
            
    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=500, detail=f"Internal Request Error: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000, timeout_graceful_shutdown=0)